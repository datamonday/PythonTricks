
def info():
    print("The word geek is a slang term originally used to describe eccentric or non-mainstream people; \
          in current use, the word typically connotes an expert or enthusiast obsessed with a hobby or intellectual pursuit,\
          with a general pejorative meaning of a peculiar person, especially one who is perceived to be overly intellectual, unfashionable, boring, or socially awkward."
          )
    # Reference:https://en.wikipedia.org/wiki/Geek
